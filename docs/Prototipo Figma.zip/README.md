
  # Premium Bakery E-commerce System

  This is a code bundle for Premium Bakery E-commerce System. The original project is available at https://www.figma.com/design/3G2F1iFJH2esEYvm6HEmdn/Premium-Bakery-E-commerce-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  