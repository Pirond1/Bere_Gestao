# 🍰 Berê Gestão - Guia do Administrador

## Bem-vinda, Maria Augusta! 

Este é o seu sistema completo de gestão e e-commerce para a Berê Gestão.

---

## 📱 Acesso ao Painel Administrativo

Para acessar o painel de administração:

**URL:** `/admin`

Exemplo: Se sua loja está em `https://meusite.com`, acesse `https://meusite.com/admin`

---

## 🎯 Funcionalidades do Admin

### 1️⃣ **Controle de Pedidos** (`/admin`)

Visualize e gerencie todos os pedidos em tempo real:

- **Status dos pedidos:**
  - 🟡 Pendente - Aguardando confirmação de pagamento
  - 🔵 Em Produção - Você está preparando o pedido
  - 🟢 Pronto - Pedido finalizado, aguardando retirada/entrega
  - ⚫ Entregue - Pedido concluído
  - 🔴 Cancelado - Pedido cancelado

- **Visão geral rápida:** Cards com quantidade de pedidos por status
- **Detalhes do pedido:** Clique na seta para ver informações completas
- **Contato direto:** Clique no telefone para abrir WhatsApp
- **Atualizar status:** Dropdown para mudar o status do pedido

### 2️⃣ **Gerenciamento de Capacidade** (`/admin/capacity`)

Controle sua disponibilidade e evite sobrecarga:

- **Calendário interativo:** Veja a ocupação de cada dia
- **Bloquear datas:** Clique em uma data e bloqueie (feriados, folgas, etc.)
- **Limite automático:** Sistema bloqueia automaticamente após 5 pedidos/dia
- **Alertas visuais:**
  - 🟢 Verde - Disponível (menos de 3 pedidos)
  - 🟠 Laranja - Vagas limitadas (4 pedidos)
  - 🟡 Amarelo - Capacidade máxima (5 pedidos)
  - 🔴 Vermelho - Data bloqueada

### 3️⃣ **Analytics & NPS** (`/admin/analytics`)

Acompanhe o desempenho do seu negócio:

- **Receita mensal:** Total de vendas do mês
- **Ticket médio:** Valor médio por pedido
- **Gráfico de receita:** Evolução nos últimos 6 meses
- **Vendas por categoria:** Qual tipo de produto mais vende
- **NPS Score:** Índice de satisfação dos clientes
- **Avaliações:** Breakdown de estrelas dos feedbacks

---

## 👥 Fluxo da Cliente (Beatriz)

### Jornada de Compra Simplificada:

1. **Landing Page** (`/`)
   - Hero com logo diamante
   - Categorias: Bolos, Tortas, Doces
   - Produtos em destaque

2. **Produtos** (`/products/cakes`, `/products/pies`, `/products/sweets`)
   - Grade de produtos com fotos e preços
   - Filtro por categoria

3. **Detalhes do Produto** (`/product/:id`)
   - Fotos de alta qualidade
   - **Calculadora de porções**: Cliente escolhe tamanho e vê quantas pessoas serve
   - Seleção de quantidade
   - Campo de personalização (para bolos customizados)

4. **Carrinho** (`/cart`)
   - Lista de itens
   - Ajustar quantidades
   - Ver total

5. **Checkout** (`/checkout`)
   - **Passo 1:** Informações do cliente
   - **Passo 2:** Escolha de data e horário (calendário inteligente!)
   - **Passo 3:** Confirmação e pagamento

6. **Pagamento** (`/payment-success`)
   - QR Code PIX dinâmico
   - Código copia e cola
   - Confirmação automática (demo: 5 segundos)
   - Resumo completo do pedido

---

## ⚡ Destaques Tecnológicos

### 🗓️ **Calendário Inteligente**
- Antecedência mínima: 2 dias
- Bloqueia automaticamente quando atingir capacidade
- Mostra disponibilidade em tempo real
- Respeita datas bloqueadas pela administradora

### 📱 **100% Mobile-First**
- Interface otimizada para celular
- Responsivo em tablets e desktops
- Menu hambúrguer em telas pequenas
- Botão WhatsApp flutuante

### 🎨 **Design Premium**
- Cores: Chocolate (#3E2723) + Dourado (#D4AF37)
- Tipografia: Playfair Display (títulos) + Inter (corpo)
- Logo diamante exclusivo
- Animações suaves e elegantes

### 💾 **Persistência Local**
- Carrinho salvo no navegador
- Pedidos armazenados localmente
- Não perde dados ao atualizar página

---

## 🚀 Próximos Passos (Para Produção)

Se você quiser colocar este sistema em produção real, será necessário:

1. **Backend/Banco de Dados:** Conectar ao Supabase ou similar
2. **Gateway de Pagamento:** Integrar API de PIX real (não mock)
3. **Autenticação Admin:** Adicionar login para proteção
4. **Notificações:** WhatsApp automático para cliente e admin
5. **Backup:** Sistema de backup dos pedidos
6. **Analytics Real:** Integração com Google Analytics

---

## 💡 Dicas de Uso

✅ **Atualize os status regularmente** - Mantém suas clientes informadas
✅ **Bloqueie datas com antecedência** - Evita pedidos em folgas/feriados
✅ **Monitore a capacidade** - Não aceite mais do que consegue produzir
✅ **Use o WhatsApp direto do sistema** - Contato rápido com clientes
✅ **Acompanhe o Analytics** - Entenda o que vende mais

---

## 📞 Contato

Este sistema foi desenvolvido especialmente para a **Berê Gestão** resolver o problema do "atraso no WhatsApp" e oferecer uma experiência premium para você e suas clientes.

**Com carinho,** 🤎
*Seu sistema de gestão automatizado*
