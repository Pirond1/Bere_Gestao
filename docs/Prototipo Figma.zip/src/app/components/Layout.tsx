import { Outlet, Link, useLocation } from 'react-router';
import { ShoppingCart, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { useCart } from '../context/CartContext';
import { motion, AnimatePresence } from 'motion/react';
import { WhatsAppButton } from './WhatsAppButton';

export function Layout() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { itemCount } = useCart();
  const location = useLocation();

  const isAdminRoute = location.pathname.startsWith('/admin');

  if (isAdminRoute) {
    return <Outlet />;
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-primary text-primary-foreground shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 md:w-12 md:h-12 rotate-45 bg-secondary flex items-center justify-center">
                <span className="-rotate-45" style={{ fontFamily: 'var(--font-serif)' }}>B</span>
              </div>
              <div className="hidden sm:block">
                <h1 className="text-lg md:text-xl" style={{ fontFamily: 'var(--font-serif)' }}>
                  Berê Gestão
                </h1>
                <p className="text-xs text-creamy-vanilla/80">Confeitaria Artesanal</p>
              </div>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-6">
              <Link to="/products/cakes" className="hover:text-secondary transition-colors">
                Bolos
              </Link>
              <Link to="/products/pies" className="hover:text-secondary transition-colors">
                Tortas
              </Link>
              <Link to="/products/sweets" className="hover:text-secondary transition-colors">
                Doces
              </Link>
            </nav>

            {/* Cart & Mobile Menu */}
            <div className="flex items-center gap-4">
              <Link to="/cart" className="relative">
                <ShoppingCart className="w-6 h-6" />
                {itemCount > 0 && (
                  <motion.span 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-2 -right-2 bg-accent text-accent-foreground text-xs w-5 h-5 rounded-full flex items-center justify-center"
                  >
                    {itemCount}
                  </motion.span>
                )}
              </Link>

              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden border-t border-primary-foreground/20 overflow-hidden"
            >
              <nav className="container mx-auto px-4 py-4 flex flex-col gap-3">
                <Link 
                  to="/products/cakes" 
                  className="py-2 hover:text-secondary transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Bolos
                </Link>
                <Link 
                  to="/products/pies" 
                  className="py-2 hover:text-secondary transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Tortas
                </Link>
                <Link 
                  to="/products/sweets" 
                  className="py-2 hover:text-secondary transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Doces
                </Link>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* WhatsApp Floating Button */}
      <WhatsAppButton />

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm opacity-80">
            © 2026 Berê Gestão - Confeitaria Artesanal Premium
          </p>
          <p className="text-xs opacity-60 mt-2">
            Feito com carinho da Dona Berê para suas clientes 🤎
          </p>
        </div>
      </footer>
    </div>
  );
}