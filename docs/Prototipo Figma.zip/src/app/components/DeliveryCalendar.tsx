import { Calendar } from '../components/ui/calendar';
import { useOrders } from '../context/OrderContext';
import { Badge } from '../components/ui/badge';
import { addDays, isSameDay, startOfDay } from 'date-fns';

interface DeliveryCalendarProps {
  selected: Date | undefined;
  onSelect: (date: Date | undefined) => void;
}

export function DeliveryCalendar({ selected, onSelect }: DeliveryCalendarProps) {
  const { orders, blockedDates } = useOrders();

  // Calculate capacity for each date
  const getDateCapacity = (date: Date): number => {
    const dateStr = date.toISOString().split('T')[0];
    return orders.filter(order => order.deliveryDate === dateStr && order.status !== 'cancelled').length;
  };

  const isDateBlocked = (date: Date): boolean => {
    const dateStr = date.toISOString().split('T')[0];
    return blockedDates.includes(dateStr);
  };

  const isDateAtCapacity = (date: Date): boolean => {
    const capacity = getDateCapacity(date);
    return capacity >= 5; // Max 5 orders per day
  };

  // Disable past dates, blocked dates, and at-capacity dates
  const disabledMatcher = (date: Date) => {
    const today = startOfDay(new Date());
    const minDate = addDays(today, 2); // Minimum 2 days advance notice
    
    return (
      date < minDate ||
      isDateBlocked(date) ||
      isDateAtCapacity(date)
    );
  };

  // Custom modifiers for styling
  const modifiers = {
    blocked: (date: Date) => isDateBlocked(date),
    nearCapacity: (date: Date) => {
      const capacity = getDateCapacity(date);
      return capacity >= 3 && capacity < 5;
    },
  };

  const modifiersStyles = {
    blocked: {
      backgroundColor: 'var(--destructive)',
      color: 'var(--destructive-foreground)',
      opacity: 0.5,
    },
    nearCapacity: {
      backgroundColor: 'var(--accent)',
      color: 'var(--accent-foreground)',
    },
  };

  return (
    <div className="space-y-4">
      <Calendar
        mode="single"
        selected={selected}
        onSelect={onSelect}
        disabled={disabledMatcher}
        modifiers={modifiers}
        modifiersStyles={modifiersStyles}
        className="rounded-lg border bg-card"
        numberOfMonths={1}
      />

      {/* Legend */}
      <div className="space-y-2 text-sm">
        <p className="text-muted-foreground mb-3">Legenda:</p>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-secondary" />
          <span>Disponível</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-accent" />
          <span>Vagas limitadas</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-destructive opacity-50" />
          <span>Indisponível</span>
        </div>
        <div className="mt-4 p-3 bg-muted/50 rounded-lg">
          <p className="text-xs text-muted-foreground">
            ⚡ Pedidos devem ser feitos com no mínimo 2 dias de antecedência
          </p>
        </div>
      </div>
    </div>
  );
}
