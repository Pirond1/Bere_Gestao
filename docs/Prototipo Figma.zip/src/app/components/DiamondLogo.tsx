interface DiamondLogoProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function DiamondLogo({ size = 'md', className = '' }: DiamondLogoProps) {
  const sizes = {
    sm: 'w-8 h-8 text-xl',
    md: 'w-12 h-12 text-2xl',
    lg: 'w-16 h-16 text-3xl',
  };

  return (
    <div className={`${sizes[size]} rotate-45 bg-secondary flex items-center justify-center shadow-lg ${className}`}>
      <span className="-rotate-45 text-primary" style={{ fontFamily: 'var(--font-serif)' }}>
        B
      </span>
    </div>
  );
}
