import { Info } from 'lucide-react';
import { Alert } from './ui/alert';

export function AdminHelp() {
  return (
    <Alert className="border-secondary/30 bg-secondary/5">
      <Info className="h-4 w-4 text-secondary" />
      <div className="ml-2">
        <h4 className="font-medium mb-1">Dica para Maria Augusta 👋</h4>
        <p className="text-sm text-muted-foreground">
          Este é seu painel de controle. Use a barra lateral para navegar entre Pedidos, Capacidade e Analytics.
          Mantenha os status atualizados para suas clientes saberem o andamento dos pedidos!
        </p>
      </div>
    </Alert>
  );
}
