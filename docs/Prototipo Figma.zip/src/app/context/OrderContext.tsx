import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem } from './CartContext';

export type OrderStatus = 'pending' | 'in-production' | 'ready' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  items: CartItem[];
  total: number;
  deliveryDate: string;
  deliveryTime: string;
  deliveryType: 'pickup' | 'delivery';
  deliveryAddress?: string;
  status: OrderStatus;
  createdAt: string;
  paymentMethod: 'pix';
  paymentStatus: 'pending' | 'confirmed';
  notes?: string;
}

interface OrderContextType {
  orders: Order[];
  addOrder: (order: Omit<Order, 'id' | 'createdAt' | 'status' | 'paymentStatus'>) => string;
  updateOrderStatus: (id: string, status: OrderStatus) => void;
  confirmPayment: (id: string) => void;
  blockedDates: string[];
  blockDate: (date: string) => void;
  unblockDate: (date: string) => void;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export function OrderProvider({ children }: { children: React.ReactNode }) {
  const [orders, setOrders] = useState<Order[]>(() => {
    const stored = localStorage.getItem('bere-orders');
    return stored ? JSON.parse(stored) : mockOrders;
  });

  const [blockedDates, setBlockedDates] = useState<string[]>(() => {
    const stored = localStorage.getItem('bere-blocked-dates');
    return stored ? JSON.parse(stored) : ['2026-04-15', '2026-05-01'];
  });

  useEffect(() => {
    localStorage.setItem('bere-orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('bere-blocked-dates', JSON.stringify(blockedDates));
  }, [blockedDates]);

  const addOrder = (orderData: Omit<Order, 'id' | 'createdAt' | 'status' | 'paymentStatus'>) => {
    const newOrder: Order = {
      ...orderData,
      id: `ORD-${Date.now()}`,
      createdAt: new Date().toISOString(),
      status: 'pending',
      paymentStatus: 'pending',
    };
    
    setOrders(prev => [newOrder, ...prev]);
    return newOrder.id;
  };

  const updateOrderStatus = (id: string, status: OrderStatus) => {
    setOrders(prev => prev.map(order => 
      order.id === id ? { ...order, status } : order
    ));
  };

  const confirmPayment = (id: string) => {
    setOrders(prev => prev.map(order => 
      order.id === id ? { ...order, paymentStatus: 'confirmed', status: 'in-production' } : order
    ));
  };

  const blockDate = (date: string) => {
    setBlockedDates(prev => [...new Set([...prev, date])]);
  };

  const unblockDate = (date: string) => {
    setBlockedDates(prev => prev.filter(d => d !== date));
  };

  return (
    <OrderContext.Provider value={{ 
      orders, 
      addOrder, 
      updateOrderStatus, 
      confirmPayment,
      blockedDates,
      blockDate,
      unblockDate
    }}>
      {children}
    </OrderContext.Provider>
  );
}

export function useOrders() {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within OrderProvider');
  }
  return context;
}

// Mock data for demo
const mockOrders: Order[] = [
  {
    id: 'ORD-1001',
    customerName: 'Beatriz Santos',
    customerPhone: '(11) 98765-4321',
    customerEmail: 'beatriz@email.com',
    items: [
      {
        id: '1',
        name: 'Bolo Red Velvet',
        price: 89.90,
        quantity: 1,
        size: '20cm',
        servings: 20,
        image: '',
      }
    ],
    total: 89.90,
    deliveryDate: '2026-04-05',
    deliveryTime: '15:00',
    deliveryType: 'pickup',
    status: 'in-production',
    createdAt: '2026-03-28T10:30:00',
    paymentMethod: 'pix',
    paymentStatus: 'confirmed',
  },
  {
    id: 'ORD-1002',
    customerName: 'Carolina Oliveira',
    customerPhone: '(11) 97654-3210',
    items: [
      {
        id: '4',
        name: 'Torta de Limão',
        price: 65.00,
        quantity: 1,
        size: '25cm',
        servings: 12,
        image: '',
      }
    ],
    total: 65.00,
    deliveryDate: '2026-04-06',
    deliveryTime: '18:00',
    deliveryType: 'delivery',
    deliveryAddress: 'Rua das Flores, 123 - Jardins',
    status: 'ready',
    createdAt: '2026-03-29T14:20:00',
    paymentMethod: 'pix',
    paymentStatus: 'confirmed',
  },
  {
    id: 'ORD-1003',
    customerName: 'Rafael Mendes',
    customerPhone: '(11) 96543-2109',
    items: [
      {
        id: '7',
        name: 'Brigadeiros Gourmet',
        price: 48.00,
        quantity: 2,
        image: '',
      }
    ],
    total: 96.00,
    deliveryDate: '2026-04-02',
    deliveryTime: '14:00',
    deliveryType: 'pickup',
    status: 'pending',
    createdAt: '2026-03-30T09:15:00',
    paymentMethod: 'pix',
    paymentStatus: 'pending',
  },
];
