import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router';
import { motion } from 'motion/react';
import { CheckCircle2, Copy, Clock, QrCode } from 'lucide-react';
import { useOrders } from '../context/OrderContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { toast } from 'sonner';

export function PaymentConfirmation() {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId');
  const { orders, confirmPayment } = useOrders();
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);

  const order = orders.find(o => o.id === orderId);

  // Mock PIX code (in production, this would come from payment gateway)
  const pixCode = `00020126580014br.gov.bcb.pix0136${orderId}520400005303986540${order?.total.toFixed(2)}5802BR5925BERE GESTAO CONFEITARIA6009SAO PAULO62070503***6304${Math.random().toString(36).substring(7).toUpperCase()}`;

  const handleCopyPix = () => {
    navigator.clipboard.writeText(pixCode);
    toast.success('Código PIX copiado!');
  };

  // Simulate payment confirmation after 5 seconds (demo only)
  useEffect(() => {
    const timer = setTimeout(() => {
      if (order && order.paymentStatus === 'pending') {
        confirmPayment(order.id);
        setPaymentConfirmed(true);
        toast.success('Pagamento confirmado!', {
          description: 'Seu pedido está sendo preparado com carinho ❤️',
        });
      }
    }, 5000);

    return () => clearTimeout(timer);
  }, [order, confirmPayment]);

  if (!order) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl mb-4">Pedido não encontrado</h2>
        <Button asChild>
          <Link to="/">Voltar ao Início</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 md:py-12 max-w-4xl">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center mb-8"
      >
        {paymentConfirmed || order.paymentStatus === 'confirmed' ? (
          <>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            >
              <CheckCircle2 className="w-20 h-20 mx-auto mb-6 text-secondary" />
            </motion.div>
            <h1 className="text-3xl md:text-4xl mb-3" style={{ fontFamily: 'var(--font-serif)' }}>
              Pagamento Confirmado!
            </h1>
            <p className="text-muted-foreground text-lg">
              Seu pedido está sendo preparado com todo carinho ❤️
            </p>
          </>
        ) : (
          <>
            <QrCode className="w-20 h-20 mx-auto mb-6 text-secondary" />
            <h1 className="text-3xl md:text-4xl mb-3" style={{ fontFamily: 'var(--font-serif)' }}>
              Finalize seu Pagamento
            </h1>
            <p className="text-muted-foreground text-lg">
              Escaneie o QR Code ou copie o código PIX
            </p>
          </>
        )}
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* PIX Payment */}
        {(!paymentConfirmed && order.paymentStatus === 'pending') && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="p-6">
              <h2 className="text-xl mb-6 text-center" style={{ fontFamily: 'var(--font-serif)' }}>
                QR Code PIX
              </h2>

              {/* Mock QR Code */}
              <div className="bg-white p-6 rounded-lg mb-6 flex items-center justify-center">
                <div className="w-48 h-48 bg-gradient-to-br from-primary to-secondary/20 rounded-lg flex items-center justify-center">
                  <QrCode className="w-32 h-32 text-primary" />
                </div>
              </div>

              <div className="space-y-3">
                <div className="p-3 bg-muted rounded-lg break-all text-sm font-mono">
                  {pixCode}
                </div>
                <Button 
                  className="w-full bg-primary hover:bg-primary/90"
                  onClick={handleCopyPix}
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copiar Código PIX
                </Button>
              </div>

              <div className="flex items-center gap-2 mt-6 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span>Aguardando confirmação do pagamento...</span>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Order Details */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className={(!paymentConfirmed && order.paymentStatus === 'pending') ? '' : 'md:col-span-2'}
        >
          <Card className="p-6">
            <h2 className="text-xl mb-6" style={{ fontFamily: 'var(--font-serif)' }}>
              Detalhes do Pedido
            </h2>

            <div className="space-y-4">
              <div className="flex justify-between pb-3 border-b border-border">
                <span className="text-muted-foreground">Número do Pedido</span>
                <span className="font-mono">{order.id}</span>
              </div>

              <div className="flex justify-between pb-3 border-b border-border">
                <span className="text-muted-foreground">Cliente</span>
                <span>{order.customerName}</span>
              </div>

              <div className="flex justify-between pb-3 border-b border-border">
                <span className="text-muted-foreground">Telefone</span>
                <span>{order.customerPhone}</span>
              </div>

              <div className="flex justify-between pb-3 border-b border-border">
                <span className="text-muted-foreground">Tipo</span>
                <span>{order.deliveryType === 'pickup' ? 'Retirada' : 'Entrega'}</span>
              </div>

              {order.deliveryAddress && (
                <div className="flex justify-between pb-3 border-b border-border">
                  <span className="text-muted-foreground">Endereço</span>
                  <span className="text-right">{order.deliveryAddress}</span>
                </div>
              )}

              <div className="flex justify-between pb-3 border-b border-border">
                <span className="text-muted-foreground">Data</span>
                <span>
                  {new Date(order.deliveryDate).toLocaleDateString('pt-BR', {
                    weekday: 'long',
                    day: '2-digit',
                    month: 'long',
                  })}
                </span>
              </div>

              <div className="flex justify-between pb-3 border-b border-border">
                <span className="text-muted-foreground">Horário</span>
                <span>{order.deliveryTime}</span>
              </div>

              <div className="pt-3">
                <p className="text-muted-foreground mb-2">Itens:</p>
                <div className="space-y-2">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span>
                        {item.quantity}x {item.name}
                        {item.size && ` (${item.size})`}
                      </span>
                      <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-between items-baseline pt-4 border-t-2 border-secondary">
                <span className="text-lg">Total</span>
                <span className="text-3xl text-secondary" style={{ fontFamily: 'var(--font-serif)' }}>
                  R$ {order.total.toFixed(2)}
                </span>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Next Steps */}
      <Card className="p-6 bg-muted/30">
        <h2 className="text-xl mb-4" style={{ fontFamily: 'var(--font-serif)' }}>
          Próximos Passos
        </h2>
        <ul className="space-y-3 text-muted-foreground">
          <li className="flex items-start gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-secondary text-primary flex items-center justify-center text-sm">
              1
            </span>
            <span>
              {paymentConfirmed || order.paymentStatus === 'confirmed' 
                ? '✓ Pagamento confirmado automaticamente'
                : 'Realize o pagamento via PIX usando o QR Code ou código acima'}
            </span>
          </li>
          <li className="flex items-start gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-secondary text-primary flex items-center justify-center text-sm">
              2
            </span>
            <span>
              Você receberá uma confirmação por WhatsApp em breve
            </span>
          </li>
          <li className="flex items-start gap-3">
            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-secondary text-primary flex items-center justify-center text-sm">
              3
            </span>
            <span>
              Seu pedido será preparado com carinho e estará pronto na data agendada
            </span>
          </li>
        </ul>
      </Card>

      <div className="text-center mt-8">
        <Button size="lg" asChild>
          <Link to="/">Voltar ao Início</Link>
        </Button>
      </div>
    </div>
  );
}
