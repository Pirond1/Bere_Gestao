import { useParams, Link } from 'react-router';
import { motion } from 'motion/react';
import { getProductsByCategory } from '../data/products';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';

const categoryNames = {
  cakes: 'Bolos',
  pies: 'Tortas',
  sweets: 'Doces',
};

const categoryDescriptions = {
  cakes: 'Bolos artesanais feitos com ingredientes premium e muito carinho',
  pies: 'Tortas clássicas e autorais com receitas exclusivas',
  sweets: 'Doces finos perfeitos para presentear ou saborear',
};

export function ProductList() {
  const { category } = useParams<{ category: string }>();
  const products = getProductsByCategory(category || '');

  const categoryName = categoryNames[category as keyof typeof categoryNames] || 'Produtos';
  const categoryDescription = categoryDescriptions[category as keyof typeof categoryDescriptions] || '';

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-10 text-center"
      >
        <h1 className="text-4xl md:text-5xl mb-3" style={{ fontFamily: 'var(--font-serif)' }}>
          {categoryName}
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          {categoryDescription}
        </p>
      </motion.div>

      {/* Products Grid */}
      {products.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-muted-foreground mb-6">Nenhum produto encontrado nesta categoria.</p>
          <Button asChild>
            <Link to="/">Voltar ao Início</Link>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="overflow-hidden hover:shadow-2xl transition-all border-2 hover:border-secondary group h-full flex flex-col">
                <Link to={`/product/${product.id}`} className="flex-1 flex flex-col">
                  <div className="aspect-[4/3] overflow-hidden relative">
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    {product.featured && (
                      <Badge className="absolute top-3 right-3 bg-secondary text-primary">
                        Destaque
                      </Badge>
                    )}
                  </div>
                  <div className="p-5 flex-1 flex flex-col">
                    <h3 className="mb-2" style={{ fontFamily: 'var(--font-serif)' }}>
                      {product.name}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 flex-1">
                      {product.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs text-muted-foreground block">A partir de</span>
                        <span className="text-xl text-secondary">
                          R$ {product.basePrice.toFixed(2)}
                        </span>
                      </div>
                      <Button className="bg-primary hover:bg-primary/90">
                        Ver Detalhes
                      </Button>
                    </div>
                  </div>
                </Link>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Back Button */}
      <div className="text-center mt-12">
        <Button variant="outline" asChild>
          <Link to="/">← Voltar ao Início</Link>
        </Button>
      </div>
    </div>
  );
}
