import { motion } from 'motion/react';
import { TrendingUp, DollarSign, Package, Star } from 'lucide-react';
import { useOrders } from '../../context/OrderContext';
import { Card } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

export function AdminAnalytics() {
  const { orders } = useOrders();

  // Calculate metrics
  const thisMonthOrders = orders.filter(order => {
    const orderDate = new Date(order.createdAt);
    const now = new Date();
    return orderDate.getMonth() === now.getMonth() && orderDate.getFullYear() === now.getFullYear();
  });

  const totalRevenue = thisMonthOrders
    .filter(o => o.paymentStatus === 'confirmed')
    .reduce((sum, order) => sum + order.total, 0);

  const avgOrderValue = thisMonthOrders.length > 0 
    ? totalRevenue / thisMonthOrders.length 
    : 0;

  // Mock NPS data
  const npsScore = 85;
  const mockFeedback = [
    { rating: 5, count: 42 },
    { rating: 4, count: 18 },
    { rating: 3, count: 5 },
    { rating: 2, count: 2 },
    { rating: 1, count: 1 },
  ];

  // Revenue by month (last 6 months)
  const revenueByMonth = [
    { month: 'Out', revenue: 3250 },
    { month: 'Nov', revenue: 4180 },
    { month: 'Dez', revenue: 5890 },
    { month: 'Jan', revenue: 4320 },
    { month: 'Fev', revenue: 3980 },
    { month: 'Mar', revenue: totalRevenue },
  ];

  // Product category distribution
  const categoryData = orders.reduce((acc, order) => {
    order.items.forEach(item => {
      const category = item.name.includes('Bolo') ? 'Bolos' 
        : item.name.includes('Torta') ? 'Tortas' 
        : 'Doces';
      
      acc[category] = (acc[category] || 0) + (item.price * item.quantity);
    });
    return acc;
  }, {} as Record<string, number>);

  const categoryChartData = Object.entries(categoryData).map(([name, value]) => ({
    name,
    value,
  }));

  const COLORS = ['#D4AF37', '#E07856', '#3E2723'];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl" style={{ fontFamily: 'var(--font-serif)' }}>
          Analytics & NPS
        </h1>
        <Badge variant="outline" className="text-base px-4 py-2">
          Março 2026
        </Badge>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="p-6 border-2 border-secondary/30 bg-secondary/5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Receita Mensal</span>
              <DollarSign className="w-5 h-5 text-secondary" />
            </div>
            <div className="text-3xl mb-1" style={{ fontFamily: 'var(--font-serif)' }}>
              R$ {totalRevenue.toFixed(2)}
            </div>
            <div className="text-xs text-secondary flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              +12% vs mês anterior
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Pedidos</span>
              <Package className="w-5 h-5 text-muted-foreground" />
            </div>
            <div className="text-3xl mb-1" style={{ fontFamily: 'var(--font-serif)' }}>
              {thisMonthOrders.length}
            </div>
            <div className="text-xs text-muted-foreground">
              Este mês
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Ticket Médio</span>
              <DollarSign className="w-5 h-5 text-muted-foreground" />
            </div>
            <div className="text-3xl mb-1" style={{ fontFamily: 'var(--font-serif)' }}>
              R$ {avgOrderValue.toFixed(2)}
            </div>
            <div className="text-xs text-muted-foreground">
              Por pedido
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="p-6 border-2 border-green-500/30 bg-green-500/5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">NPS Score</span>
              <Star className="w-5 h-5 text-green-600" />
            </div>
            <div className="text-3xl mb-1 text-green-600" style={{ fontFamily: 'var(--font-serif)' }}>
              {npsScore}
            </div>
            <div className="text-xs text-muted-foreground">
              Excelente satisfação
            </div>
          </Card>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <Card className="p-6">
          <h2 className="text-xl mb-6" style={{ fontFamily: 'var(--font-serif)' }}>
            Receita Mensal
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={revenueByMonth}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis 
                dataKey="month" 
                stroke="var(--muted-foreground)"
                style={{ fontSize: '12px' }}
              />
              <YAxis 
                stroke="var(--muted-foreground)"
                style={{ fontSize: '12px' }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'var(--card)',
                  border: '1px solid var(--border)',
                  borderRadius: '8px',
                }}
              />
              <Line 
                type="monotone" 
                dataKey="revenue" 
                stroke="var(--secondary)"
                strokeWidth={3}
                dot={{ fill: 'var(--secondary)', r: 5 }}
                activeDot={{ r: 7 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Category Distribution */}
        <Card className="p-6">
          <h2 className="text-xl mb-6" style={{ fontFamily: 'var(--font-serif)' }}>
            Vendas por Categoria
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={categoryChartData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {categoryChartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: 'var(--card)',
                  border: '1px solid var(--border)',
                  borderRadius: '8px',
                }}
                formatter={(value: number) => `R$ ${value.toFixed(2)}`}
              />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Customer Satisfaction */}
      <Card className="p-6">
        <h2 className="text-xl mb-6" style={{ fontFamily: 'var(--font-serif)' }}>
          Avaliações dos Clientes
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* NPS Gauge */}
          <div className="flex flex-col items-center justify-center">
            <div className="relative w-48 h-48 mb-4">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="96"
                  cy="96"
                  r="80"
                  stroke="var(--muted)"
                  strokeWidth="16"
                  fill="none"
                />
                <circle
                  cx="96"
                  cy="96"
                  r="80"
                  stroke="var(--secondary)"
                  strokeWidth="16"
                  fill="none"
                  strokeDasharray={`${(npsScore / 100) * 502.4} 502.4`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="text-5xl text-secondary" style={{ fontFamily: 'var(--font-serif)' }}>
                  {npsScore}
                </div>
                <div className="text-sm text-muted-foreground">NPS Score</div>
              </div>
            </div>
            <Badge className="bg-green-500/20 text-green-700 border-green-500/30">
              Zona de Excelência
            </Badge>
          </div>

          {/* Rating Breakdown */}
          <div className="space-y-3">
            {mockFeedback.map((item) => (
              <div key={item.rating} className="flex items-center gap-3">
                <div className="flex items-center gap-1 w-16">
                  {Array.from({ length: item.rating }).map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-secondary text-secondary" />
                  ))}
                </div>
                <div className="flex-1">
                  <div className="h-8 bg-muted rounded-lg overflow-hidden">
                    <div
                      className="h-full bg-secondary transition-all"
                      style={{
                        width: `${(item.count / mockFeedback.reduce((sum, f) => sum + f.count, 0)) * 100}%`,
                      }}
                    />
                  </div>
                </div>
                <span className="text-sm text-muted-foreground w-12 text-right">
                  {item.count}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="p-4 bg-muted/30">
            <div className="text-sm text-muted-foreground mb-1">Promotores</div>
            <div className="text-2xl text-green-600">88%</div>
          </Card>
          <Card className="p-4 bg-muted/30">
            <div className="text-sm text-muted-foreground mb-1">Neutros</div>
            <div className="text-2xl text-yellow-600">9%</div>
          </Card>
          <Card className="p-4 bg-muted/30">
            <div className="text-sm text-muted-foreground mb-1">Detratores</div>
            <div className="text-2xl text-red-600">3%</div>
          </Card>
        </div>
      </Card>
    </div>
  );
}
