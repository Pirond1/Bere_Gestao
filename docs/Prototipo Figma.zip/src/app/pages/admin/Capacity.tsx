import { useState } from 'react';
import { motion } from 'motion/react';
import { Calendar as CalendarIcon, XCircle, Plus } from 'lucide-react';
import { useOrders } from '../../context/OrderContext';
import { Card } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Calendar } from '../../components/ui/calendar';
import { Badge } from '../../components/ui/badge';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function AdminCapacity() {
  const { orders, blockedDates, blockDate, unblockDate } = useOrders();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);

  const getDateOrders = (date: Date): number => {
    const dateStr = date.toISOString().split('T')[0];
    return orders.filter(order => order.deliveryDate === dateStr && order.status !== 'cancelled').length;
  };

  const isDateBlocked = (date: Date): boolean => {
    const dateStr = date.toISOString().split('T')[0];
    return blockedDates.includes(dateStr);
  };

  const handleToggleBlock = () => {
    if (!selectedDate) return;

    const dateStr = selectedDate.toISOString().split('T')[0];
    if (isDateBlocked(selectedDate)) {
      unblockDate(dateStr);
    } else {
      blockDate(dateStr);
    }
  };

  const upcomingBlockedDates = blockedDates
    .map(d => new Date(d))
    .filter(d => d >= new Date())
    .sort((a, b) => a.getTime() - b.getTime())
    .slice(0, 10);

  const capacityByDate = orders
    .filter(o => o.status !== 'cancelled' && new Date(o.deliveryDate) >= new Date())
    .reduce((acc, order) => {
      const date = order.deliveryDate;
      acc[date] = (acc[date] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

  const highCapacityDates = Object.entries(capacityByDate)
    .filter(([_, count]) => count >= 4)
    .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl" style={{ fontFamily: 'var(--font-serif)' }}>
          Gerenciar Capacidade
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Calendar */}
        <Card className="p-6">
          <h2 className="text-xl mb-4" style={{ fontFamily: 'var(--font-serif)' }}>
            Bloquear/Desbloquear Datas
          </h2>

          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            disabled={(date) => date < new Date()}
            modifiers={{
              blocked: (date) => isDateBlocked(date),
              nearCapacity: (date) => {
                const count = getDateOrders(date);
                return count >= 4 && count < 5;
              },
              atCapacity: (date) => getDateOrders(date) >= 5,
            }}
            modifiersStyles={{
              blocked: {
                backgroundColor: 'var(--destructive)',
                color: 'var(--destructive-foreground)',
              },
              nearCapacity: {
                backgroundColor: 'var(--accent)',
                color: 'var(--accent-foreground)',
              },
              atCapacity: {
                backgroundColor: 'var(--secondary)',
                color: 'var(--primary)',
              },
            }}
            className="rounded-lg border"
          />

          {selectedDate && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 p-4 bg-muted/30 rounded-lg"
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="mb-1">
                    {format(selectedDate, "d 'de' MMMM 'de' yyyy", { locale: ptBR })}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {getDateOrders(selectedDate)} pedido(s) agendado(s)
                  </div>
                </div>
                <Badge className={isDateBlocked(selectedDate) ? 'bg-destructive' : 'bg-secondary'}>
                  {isDateBlocked(selectedDate) ? 'Bloqueado' : 'Disponível'}
                </Badge>
              </div>

              <Button
                onClick={handleToggleBlock}
                variant={isDateBlocked(selectedDate) ? 'default' : 'destructive'}
                className="w-full"
              >
                {isDateBlocked(selectedDate) ? (
                  <>
                    <Plus className="w-4 h-4 mr-2" />
                    Desbloquear Data
                  </>
                ) : (
                  <>
                    <XCircle className="w-4 h-4 mr-2" />
                    Bloquear Data
                  </>
                )}
              </Button>
            </motion.div>
          )}
        </Card>

        {/* Stats & Lists */}
        <div className="space-y-6">
          {/* Blocked Dates */}
          <Card className="p-6">
            <h2 className="text-xl mb-4" style={{ fontFamily: 'var(--font-serif)' }}>
              Datas Bloqueadas
            </h2>

            {upcomingBlockedDates.length === 0 ? (
              <p className="text-muted-foreground text-sm">
                Nenhuma data bloqueada no momento
              </p>
            ) : (
              <div className="space-y-2">
                {upcomingBlockedDates.map((date) => (
                  <div
                    key={date.toISOString()}
                    className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <CalendarIcon className="w-4 h-4 text-destructive" />
                      <span className="text-sm">
                        {format(date, "d 'de' MMMM", { locale: ptBR })}
                      </span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => unblockDate(date.toISOString().split('T')[0])}
                    >
                      <XCircle className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </Card>

          {/* High Capacity Dates */}
          <Card className="p-6">
            <h2 className="text-xl mb-4" style={{ fontFamily: 'var(--font-serif)' }}>
              Datas com Alta Demanda
            </h2>

            {highCapacityDates.length === 0 ? (
              <p className="text-muted-foreground text-sm">
                Nenhuma data com alta demanda no momento
              </p>
            ) : (
              <div className="space-y-2">
                {highCapacityDates.map(([dateStr, count]) => {
                  const date = new Date(dateStr);
                  return (
                    <div
                      key={dateStr}
                      className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
                    >
                      <div>
                        <div className="text-sm mb-1">
                          {format(date, "d 'de' MMMM", { locale: ptBR })}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {count} de 5 vagas ocupadas
                        </div>
                      </div>
                      <Badge variant="outline" className="bg-accent/20">
                        {count === 5 ? 'Lotado' : 'Quase lotado'}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>

          {/* Legend */}
          <Card className="p-6 bg-muted/20">
            <h3 className="text-sm uppercase tracking-wide text-muted-foreground mb-3">
              Legenda
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-secondary" />
                <span>Capacidade máxima (5 pedidos)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-accent" />
                <span>Vagas limitadas (4 pedidos)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-destructive" />
                <span>Data bloqueada</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}