import { useState } from 'react';
import { motion } from 'motion/react';
import { Clock, MapPin, Phone, User, ChevronDown, ChevronUp } from 'lucide-react';
import { useOrders, OrderStatus } from '../../context/OrderContext';
import { Card } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';

const statusColors: Record<OrderStatus, string> = {
  'pending': 'bg-yellow-500/20 text-yellow-700 border-yellow-500/30',
  'in-production': 'bg-blue-500/20 text-blue-700 border-blue-500/30',
  'ready': 'bg-green-500/20 text-green-700 border-green-500/30',
  'delivered': 'bg-gray-500/20 text-gray-700 border-gray-500/30',
  'cancelled': 'bg-red-500/20 text-red-700 border-red-500/30',
};

const statusLabels: Record<OrderStatus, string> = {
  'pending': 'Pendente',
  'in-production': 'Em Produção',
  'ready': 'Pronto',
  'delivered': 'Entregue',
  'cancelled': 'Cancelado',
};

export function AdminOrders() {
  const { orders, updateOrderStatus } = useOrders();
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredOrders = filterStatus === 'all' 
    ? orders 
    : orders.filter(order => order.status === filterStatus);

  const sortedOrders = [...filteredOrders].sort((a, b) => {
    // Sort by delivery date, then by status priority
    const dateCompare = new Date(a.deliveryDate).getTime() - new Date(b.deliveryDate).getTime();
    if (dateCompare !== 0) return dateCompare;
    
    const statusPriority: Record<OrderStatus, number> = {
      'pending': 1,
      'in-production': 2,
      'ready': 3,
      'delivered': 4,
      'cancelled': 5,
    };
    
    return statusPriority[a.status] - statusPriority[b.status];
  });

  const getStatusCount = (status: OrderStatus) => {
    return orders.filter(order => order.status === status).length;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl" style={{ fontFamily: 'var(--font-serif)' }}>
          Controle de Pedidos
        </h1>
      </div>

      {/* Status Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4 border-2 border-yellow-500/30 bg-yellow-500/5">
          <div className="text-2xl mb-1">{getStatusCount('pending')}</div>
          <div className="text-sm text-muted-foreground">Pendentes</div>
        </Card>
        <Card className="p-4 border-2 border-blue-500/30 bg-blue-500/5">
          <div className="text-2xl mb-1">{getStatusCount('in-production')}</div>
          <div className="text-sm text-muted-foreground">Em Produção</div>
        </Card>
        <Card className="p-4 border-2 border-green-500/30 bg-green-500/5">
          <div className="text-2xl mb-1">{getStatusCount('ready')}</div>
          <div className="text-sm text-muted-foreground">Prontos</div>
        </Card>
        <Card className="p-4 border-2 border-gray-500/30 bg-gray-500/5">
          <div className="text-2xl mb-1">{getStatusCount('delivered')}</div>
          <div className="text-sm text-muted-foreground">Entregues</div>
        </Card>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-4">
        <span className="text-sm text-muted-foreground">Filtrar por status:</span>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="pending">Pendentes</SelectItem>
            <SelectItem value="in-production">Em Produção</SelectItem>
            <SelectItem value="ready">Prontos</SelectItem>
            <SelectItem value="delivered">Entregues</SelectItem>
            <SelectItem value="cancelled">Cancelados</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        {sortedOrders.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground">Nenhum pedido encontrado</p>
          </Card>
        ) : (
          sortedOrders.map((order, index) => (
            <motion.div
              key={order.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="overflow-hidden">
                {/* Order Header */}
                <div className="p-4 bg-muted/30">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-4 flex-1 min-w-0">
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">
                          {new Date(order.deliveryDate).toLocaleDateString('pt-BR', {
                            day: '2-digit',
                            month: 'short',
                          })} • {order.deliveryTime}
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-sm">{order.id}</span>
                          <Badge className={`border ${statusColors[order.status]}`}>
                            {statusLabels[order.status]}
                          </Badge>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right hidden md:block">
                        <div className="text-xs text-muted-foreground mb-1">Total</div>
                        <div className="text-lg text-secondary">
                          R$ {order.total.toFixed(2)}
                        </div>
                      </div>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
                      >
                        {expandedOrder === order.id ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Order Details (Expanded) */}
                {expandedOrder === order.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="p-4 border-t border-border"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Customer Info */}
                      <div className="space-y-3">
                        <h3 className="text-sm uppercase tracking-wide text-muted-foreground mb-3">
                          Cliente
                        </h3>
                        
                        <div className="flex items-center gap-3">
                          <User className="w-4 h-4 text-muted-foreground" />
                          <span>{order.customerName}</span>
                        </div>

                        <div className="flex items-center gap-3">
                          <Phone className="w-4 h-4 text-muted-foreground" />
                          <a 
                            href={`https://wa.me/${order.customerPhone.replace(/\D/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-secondary hover:underline"
                          >
                            {order.customerPhone}
                          </a>
                        </div>

                        {order.customerEmail && (
                          <div className="flex items-center gap-3 text-sm text-muted-foreground">
                            {order.customerEmail}
                          </div>
                        )}

                        <div className="flex items-start gap-3">
                          <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                          <div>
                            <div className="mb-1">
                              {order.deliveryType === 'pickup' ? 'Retirada' : 'Entrega'}
                            </div>
                            {order.deliveryAddress && (
                              <div className="text-sm text-muted-foreground">
                                {order.deliveryAddress}
                              </div>
                            )}
                          </div>
                        </div>

                        {order.notes && (
                          <div className="pt-3 border-t border-border">
                            <div className="text-sm text-muted-foreground mb-1">Observações:</div>
                            <div className="text-sm">{order.notes}</div>
                          </div>
                        )}
                      </div>

                      {/* Items & Status */}
                      <div className="space-y-3">
                        <h3 className="text-sm uppercase tracking-wide text-muted-foreground mb-3">
                          Itens
                        </h3>

                        <div className="space-y-2">
                          {order.items.map((item, idx) => (
                            <div key={idx} className="flex justify-between text-sm">
                              <span>
                                {item.quantity}x {item.name}
                                {item.size && ` (${item.size})`}
                              </span>
                              <span className="text-muted-foreground">
                                R$ {(item.price * item.quantity).toFixed(2)}
                              </span>
                            </div>
                          ))}
                        </div>

                        <div className="pt-3 border-t border-border">
                          <div className="flex justify-between mb-3">
                            <span>Total</span>
                            <span className="text-lg text-secondary">
                              R$ {order.total.toFixed(2)}
                            </span>
                          </div>

                          <div className="space-y-2">
                            <label className="text-sm text-muted-foreground">
                              Atualizar Status:
                            </label>
                            <Select
                              value={order.status}
                              onValueChange={(value: OrderStatus) => updateOrderStatus(order.id, value)}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pending">Pendente</SelectItem>
                                <SelectItem value="in-production">Em Produção</SelectItem>
                                <SelectItem value="ready">Pronto</SelectItem>
                                <SelectItem value="delivered">Entregue</SelectItem>
                                <SelectItem value="cancelled">Cancelado</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </Card>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
