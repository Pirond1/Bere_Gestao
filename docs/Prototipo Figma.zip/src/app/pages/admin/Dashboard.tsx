import { Link, Outlet, useLocation } from 'react-router';
import { Package, Calendar, BarChart3, LogOut, Home } from 'lucide-react';
import { Button } from '../../components/ui/button';

export function AdminDashboard() {
  const location = useLocation();

  const isActive = (path: string) => {
    if (path === '/admin' && location.pathname === '/admin') return true;
    if (path !== '/admin' && location.pathname.startsWith(path)) return true;
    return false;
  };

  return (
    <div className="min-h-screen bg-primary text-primary-foreground">
      {/* Admin Header */}
      <header className="border-b border-primary-foreground/20 bg-primary/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rotate-45 bg-secondary flex items-center justify-center">
                <span className="-rotate-45" style={{ fontFamily: 'var(--font-serif)' }}>B</span>
              </div>
              <div>
                <h1 className="text-lg" style={{ fontFamily: 'var(--font-serif)' }}>
                  Admin Dashboard
                </h1>
                <p className="text-xs text-primary-foreground/70">
                  Gerenciamento Berê Gestão
                </p>
              </div>
            </div>

            <Button variant="ghost" size="sm" className="text-primary-foreground" asChild>
              <Link to="/">
                <Home className="w-4 h-4 mr-2" />
                Ver Loja
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 min-h-[calc(100vh-4rem)] border-r border-primary-foreground/20 p-4">
          <nav className="space-y-2">
            <Link
              to="/admin"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive('/admin')
                  ? 'bg-secondary text-primary'
                  : 'hover:bg-primary-foreground/10'
              }`}
            >
              <Package className="w-5 h-5" />
              <span>Pedidos</span>
            </Link>

            <Link
              to="/admin/capacity"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive('/admin/capacity')
                  ? 'bg-secondary text-primary'
                  : 'hover:bg-primary-foreground/10'
              }`}
            >
              <Calendar className="w-5 h-5" />
              <span>Capacidade</span>
            </Link>

            <Link
              to="/admin/analytics"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive('/admin/analytics')
                  ? 'bg-secondary text-primary'
                  : 'hover:bg-primary-foreground/10'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              <span>Analytics</span>
            </Link>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 bg-background text-foreground">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
