import { Link } from 'react-router';
import { motion } from 'motion/react';
import { Cake, PieChart, Sparkles, ArrowRight } from 'lucide-react';
import { getFeaturedProducts } from '../data/products';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';

export function Home() {
  const featured = getFeaturedProducts();

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[70vh] md:h-[80vh] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1737700088028-fae0666feb83?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwYmFrZXJ5JTIwZGlzcGxheXxlbnwxfHx8fDE3NzQ5MDI4MjV8MA&ixlib=rb-4.1.0&q=80&w=1080)',
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-primary/80 via-primary/60 to-primary/80" />
        </div>

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          {/* Diamond Logo */}
          <motion.div
            initial={{ scale: 0, rotate: 0 }}
            animate={{ scale: 1, rotate: 45 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="w-20 h-20 md:w-24 md:h-24 mx-auto mb-6 bg-secondary flex items-center justify-center shadow-2xl"
          >
            <motion.span 
              initial={{ rotate: 0 }}
              animate={{ rotate: -45 }}
              className="text-3xl md:text-4xl text-primary"
              style={{ fontFamily: 'var(--font-serif)' }}
            >
              B
            </motion.span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-4xl md:text-6xl mb-4 text-creamy-vanilla"
            style={{ fontFamily: 'var(--font-serif)' }}
          >
            Berê Gestão
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-lg md:text-2xl text-creamy-vanilla/90 mb-8"
          >
            Confeitaria Artesanal Premium
          </motion.p>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="text-base md:text-lg text-creamy-vanilla/80 mb-8 max-w-2xl mx-auto"
          >
            Saboreie a excelência em cada pedaço. Peça agora e receba no conforto da sua casa.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
          >
            <Button 
              size="lg"
              className="bg-secondary text-primary hover:bg-secondary/90 shadow-xl"
              asChild
            >
              <Link to="/products/cakes">
                Ver Cardápio <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="container mx-auto px-4 py-12 md:py-16">
        <h2 className="text-3xl md:text-4xl text-center mb-10" style={{ fontFamily: 'var(--font-serif)' }}>
          Nossas Especialidades
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Link to="/products/cakes">
              <Card className="p-8 text-center bg-card hover:shadow-xl transition-all border-2 hover:border-secondary">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-secondary/10 flex items-center justify-center">
                  <Cake className="w-8 h-8 text-secondary" />
                </div>
                <h3 className="mb-2" style={{ fontFamily: 'var(--font-serif)' }}>Bolos</h3>
                <p className="text-sm text-muted-foreground">
                  Bolos artesanais para celebrações inesquecíveis
                </p>
              </Card>
            </Link>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Link to="/products/pies">
              <Card className="p-8 text-center bg-card hover:shadow-xl transition-all border-2 hover:border-secondary">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-secondary/10 flex items-center justify-center">
                  <PieChart className="w-8 h-8 text-secondary" />
                </div>
                <h3 className="mb-2" style={{ fontFamily: 'var(--font-serif)' }}>Tortas</h3>
                <p className="text-sm text-muted-foreground">
                  Tortas clássicas e autorais feitas à mão
                </p>
              </Card>
            </Link>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Link to="/products/sweets">
              <Card className="p-8 text-center bg-card hover:shadow-xl transition-all border-2 hover:border-secondary">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-secondary/10 flex items-center justify-center">
                  <Sparkles className="w-8 h-8 text-secondary" />
                </div>
                <h3 className="mb-2" style={{ fontFamily: 'var(--font-serif)' }}>Doces</h3>
                <p className="text-sm text-muted-foreground">
                  Doces finos e sofisticados para todos os gostos
                </p>
              </Card>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="bg-muted/30 py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl text-center mb-10" style={{ fontFamily: 'var(--font-serif)' }}>
            Destaques da Semana
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featured.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Link to={`/product/${product.id}`}>
                  <Card className="overflow-hidden hover:shadow-2xl transition-all border-2 hover:border-secondary group">
                    <div className="aspect-square overflow-hidden">
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-4">
                      <h3 className="mb-2" style={{ fontFamily: 'var(--font-serif)' }}>
                        {product.name}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                        {product.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-lg text-secondary">
                          R$ {product.basePrice.toFixed(2)}
                        </span>
                        <Button size="sm" className="bg-primary hover:bg-primary/90">
                          Ver Mais
                        </Button>
                      </div>
                    </div>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-3xl md:text-4xl mb-4" style={{ fontFamily: 'var(--font-serif)' }}>
          Pronta para fazer seu pedido?
        </h2>
        <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
          Nosso sistema de agendamento inteligente garante que seu pedido seja entregue no momento perfeito.
        </p>
        <Button size="lg" className="bg-primary hover:bg-primary/90" asChild>
          <Link to="/products/cakes">
            Fazer Pedido Agora <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </Button>
      </section>
    </div>
  );
}
