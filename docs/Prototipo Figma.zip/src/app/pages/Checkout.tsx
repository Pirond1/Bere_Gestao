import { useState } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { Calendar, Clock, MapPin, User, Phone, Mail, CreditCard } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useOrders } from '../context/OrderContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { DeliveryCalendar } from '../components/DeliveryCalendar';
import { toast } from 'sonner';

export function Checkout() {
  const { items, total, clearCart } = useCart();
  const { addOrder } = useOrders();
  const navigate = useNavigate();

  const [step, setStep] = useState<'info' | 'schedule' | 'payment'>('info');
  
  // Customer Info
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  
  // Delivery
  const [deliveryType, setDeliveryType] = useState<'pickup' | 'delivery'>('pickup');
  const [address, setAddress] = useState('');
  
  // Schedule
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState('');
  
  // Additional
  const [notes, setNotes] = useState('');

  const deliveryFee = deliveryType === 'delivery' ? 15.00 : 0;
  const finalTotal = total + deliveryFee;

  const handleInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }
    setStep('schedule');
  };

  const handleScheduleSubmit = () => {
    if (!selectedDate || !selectedTime) {
      toast.error('Selecione data e horário de entrega');
      return;
    }
    setStep('payment');
  };

  const handlePayment = () => {
    if (!selectedDate) return;

    const orderId = addOrder({
      customerName: name,
      customerPhone: phone,
      customerEmail: email,
      items,
      total: finalTotal,
      deliveryDate: selectedDate.toISOString().split('T')[0],
      deliveryTime: selectedTime,
      deliveryType,
      deliveryAddress: deliveryType === 'delivery' ? address : undefined,
      paymentMethod: 'pix',
      notes: notes.trim() || undefined,
    });

    clearCart();
    navigate(`/payment-success?orderId=${orderId}`);
  };

  if (items.length === 0) {
    navigate('/cart');
    return null;
  }

  const timeSlots = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00', '17:00', '18:00'];

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl md:text-4xl mb-8"
        style={{ fontFamily: 'var(--font-serif)' }}
      >
        Finalizar Pedido
      </motion.h1>

      {/* Progress Steps */}
      <div className="flex items-center justify-center gap-2 mb-12 flex-wrap">
        <div className={`flex items-center gap-2 ${step === 'info' ? 'text-primary' : step === 'schedule' || step === 'payment' ? 'text-secondary' : 'text-muted-foreground'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step === 'info' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-primary'}`}>
            1
          </div>
          <span className="hidden sm:inline">Informações</span>
        </div>
        <div className="w-12 h-0.5 bg-border" />
        <div className={`flex items-center gap-2 ${step === 'schedule' ? 'text-primary' : step === 'payment' ? 'text-secondary' : 'text-muted-foreground'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step === 'schedule' ? 'bg-primary text-primary-foreground' : step === 'payment' ? 'bg-secondary text-primary' : 'bg-muted text-muted-foreground'}`}>
            2
          </div>
          <span className="hidden sm:inline">Agendamento</span>
        </div>
        <div className="w-12 h-0.5 bg-border" />
        <div className={`flex items-center gap-2 ${step === 'payment' ? 'text-primary' : 'text-muted-foreground'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step === 'payment' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
            3
          </div>
          <span className="hidden sm:inline">Pagamento</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2">
          {/* Step 1: Info */}
          {step === 'info' && (
            <motion.form
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              onSubmit={handleInfoSubmit}
              className="space-y-6"
            >
              <Card className="p-6">
                <h2 className="flex items-center gap-2 text-xl mb-6" style={{ fontFamily: 'var(--font-serif)' }}>
                  <User className="w-5 h-5 text-secondary" />
                  Suas Informações
                </h2>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Nome Completo *</Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Beatriz Santos"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Telefone/WhatsApp *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="(11) 98765-4321"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="email">E-mail (Opcional)</Label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="beatriz@email.com"
                    />
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <h2 className="flex items-center gap-2 text-xl mb-6" style={{ fontFamily: 'var(--font-serif)' }}>
                  <MapPin className="w-5 h-5 text-secondary" />
                  Forma de Recebimento
                </h2>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      type="button"
                      onClick={() => setDeliveryType('pickup')}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        deliveryType === 'pickup'
                          ? 'border-secondary bg-secondary/10'
                          : 'border-border hover:border-secondary/50'
                      }`}
                    >
                      <div className="text-center">
                        <span className="block mb-1">Retirada</span>
                        <span className="text-sm text-muted-foreground">Grátis</span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDeliveryType('delivery')}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        deliveryType === 'delivery'
                          ? 'border-secondary bg-secondary/10'
                          : 'border-border hover:border-secondary/50'
                      }`}
                    >
                      <div className="text-center">
                        <span className="block mb-1">Entrega</span>
                        <span className="text-sm text-muted-foreground">R$ 15,00</span>
                      </div>
                    </button>
                  </div>

                  {deliveryType === 'delivery' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                    >
                      <Label htmlFor="address">Endereço de Entrega *</Label>
                      <Textarea
                        id="address"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="Rua, número, complemento, bairro, cidade"
                        rows={3}
                        required={deliveryType === 'delivery'}
                      />
                    </motion.div>
                  )}
                </div>
              </Card>

              <Button type="submit" size="lg" className="w-full bg-primary hover:bg-primary/90">
                Continuar para Agendamento
              </Button>
            </motion.form>
          )}

          {/* Step 2: Schedule */}
          {step === 'schedule' && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              <Card className="p-6">
                <h2 className="flex items-center gap-2 text-xl mb-6" style={{ fontFamily: 'var(--font-serif)' }}>
                  <Calendar className="w-5 h-5 text-secondary" />
                  Escolha a Data
                </h2>

                <DeliveryCalendar
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                />
              </Card>

              {selectedDate && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <Card className="p-6">
                    <h2 className="flex items-center gap-2 text-xl mb-6" style={{ fontFamily: 'var(--font-serif)' }}>
                      <Clock className="w-5 h-5 text-secondary" />
                      Escolha o Horário
                    </h2>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {timeSlots.map((time) => (
                        <button
                          key={time}
                          type="button"
                          onClick={() => setSelectedTime(time)}
                          className={`p-3 rounded-lg border-2 transition-all ${
                            selectedTime === time
                              ? 'border-secondary bg-secondary/10'
                              : 'border-border hover:border-secondary/50'
                          }`}
                        >
                          {time}
                        </button>
                      ))}
                    </div>
                  </Card>
                </motion.div>
              )}

              <Card className="p-6">
                <Label htmlFor="notes">Observações (Opcional)</Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Algum pedido especial ou informação adicional?"
                  rows={3}
                />
              </Card>

              <div className="flex gap-4">
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="flex-1"
                  onClick={() => setStep('info')}
                >
                  Voltar
                </Button>
                <Button 
                  size="lg" 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  onClick={handleScheduleSubmit}
                  disabled={!selectedDate || !selectedTime}
                >
                  Continuar para Pagamento
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 3: Payment */}
          {step === 'payment' && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              <Card className="p-6">
                <h2 className="flex items-center gap-2 text-xl mb-6" style={{ fontFamily: 'var(--font-serif)' }}>
                  <CreditCard className="w-5 h-5 text-secondary" />
                  Método de Pagamento
                </h2>

                <div className="text-center py-8">
                  <p className="text-muted-foreground mb-4">
                    O QR Code e instruções de pagamento aparecerão na próxima tela
                  </p>
                  <div className="w-16 h-16 mx-auto bg-secondary/20 rounded-lg flex items-center justify-center">
                    <CreditCard className="w-8 h-8 text-secondary" />
                  </div>
                  <p className="mt-4">Pagamento via PIX</p>
                </div>
              </Card>

              <div className="flex gap-4">
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="flex-1"
                  onClick={() => setStep('schedule')}
                >
                  Voltar
                </Button>
                <Button 
                  size="lg" 
                  className="flex-1 bg-secondary text-primary hover:bg-secondary/90"
                  onClick={handlePayment}
                >
                  Gerar PIX e Finalizar
                </Button>
              </div>
            </motion.div>
          )}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="sticky top-24">
            <Card className="p-6">
              <h2 className="text-xl mb-6" style={{ fontFamily: 'var(--font-serif)' }}>
                Resumo do Pedido
              </h2>

              <div className="space-y-3 mb-6 max-h-64 overflow-y-auto">
                {items.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="flex-1">
                      {item.quantity}x {item.name}
                      {item.size && ` (${item.size})`}
                    </span>
                    <span className="text-muted-foreground">
                      R$ {(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="space-y-2 text-sm border-t border-border pt-4 mb-4">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>R$ {total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Taxa de {deliveryType === 'delivery' ? 'entrega' : 'retirada'}</span>
                  <span className={deliveryFee === 0 ? 'text-secondary' : ''}>
                    {deliveryFee === 0 ? 'Grátis' : `R$ ${deliveryFee.toFixed(2)}`}
                  </span>
                </div>
              </div>

              <div className="border-t border-border pt-4">
                <div className="flex justify-between items-baseline">
                  <span className="text-lg">Total</span>
                  <span className="text-3xl text-secondary" style={{ fontFamily: 'var(--font-serif)' }}>
                    R$ {finalTotal.toFixed(2)}
                  </span>
                </div>
              </div>

              {step === 'schedule' && selectedDate && (
                <div className="mt-6 pt-6 border-t border-border text-sm">
                  <p className="text-muted-foreground mb-2">Agendado para:</p>
                  <p>
                    {selectedDate.toLocaleDateString('pt-BR', { 
                      weekday: 'long', 
                      day: '2-digit', 
                      month: 'long' 
                    })}
                  </p>
                  {selectedTime && <p>às {selectedTime}</p>}
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
