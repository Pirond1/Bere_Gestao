import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router';
import { motion } from 'motion/react';
import { ShoppingCart, Calculator, ArrowLeft, Plus, Minus } from 'lucide-react';
import { getProductById } from '../data/products';
import { useCart } from '../context/CartContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { toast } from 'sonner';

export function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addItem } = useCart();
  const product = getProductById(id || '');

  const [selectedSize, setSelectedSize] = useState(product?.sizes?.[0] || null);
  const [quantity, setQuantity] = useState(1);
  const [customization, setCustomization] = useState('');

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl mb-4">Produto não encontrado</h2>
        <Button asChild>
          <Link to="/">Voltar ao Início</Link>
        </Button>
      </div>
    );
  }

  const currentPrice = selectedSize ? selectedSize.price : product.basePrice;
  const totalPrice = currentPrice * quantity;

  const handleAddToCart = () => {
    addItem({
      id: `${product.id}-${selectedSize?.size || 'default'}-${Date.now()}`,
      name: product.name,
      price: currentPrice,
      quantity,
      size: selectedSize?.size,
      servings: selectedSize?.servings,
      image: product.image,
      customization: customization.trim() || undefined,
    });

    toast.success('Produto adicionado ao carrinho!', {
      description: `${quantity}x ${product.name}`,
    });

    navigate('/cart');
  };

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      {/* Back Button */}
      <Button variant="ghost" className="mb-6" asChild>
        <Link to={`/products/${product.category}`}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar para {product.category === 'cakes' ? 'Bolos' : product.category === 'pies' ? 'Tortas' : 'Doces'}
        </Link>
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
        {/* Image Gallery */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <Card className="overflow-hidden shadow-xl">
            <img 
              src={product.image} 
              alt={product.name}
              className="w-full aspect-square object-cover"
            />
          </Card>
        </motion.div>

        {/* Product Info */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          <div>
            <h1 className="text-3xl md:text-4xl mb-3" style={{ fontFamily: 'var(--font-serif)' }}>
              {product.name}
            </h1>
            <p className="text-muted-foreground text-lg">
              {product.description}
            </p>
          </div>

          <div className="flex items-baseline gap-3">
            <span className="text-4xl text-secondary" style={{ fontFamily: 'var(--font-serif)' }}>
              R$ {currentPrice.toFixed(2)}
            </span>
            {selectedSize && (
              <span className="text-sm text-muted-foreground">
                por unidade
              </span>
            )}
          </div>

          {/* Size Selection with Servings Calculator */}
          {product.sizes && product.sizes.length > 0 && (
            <Card className="p-6 bg-muted/20 border-2 border-secondary/20">
              <div className="flex items-center gap-2 mb-4">
                <Calculator className="w-5 h-5 text-secondary" />
                <Label className="text-base">Escolha o Tamanho</Label>
              </div>
              
              <div className="grid grid-cols-1 gap-3">
                {product.sizes.map((size) => (
                  <button
                    key={size.size}
                    onClick={() => setSelectedSize(size)}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      selectedSize?.size === size.size
                        ? 'border-secondary bg-secondary/10'
                        : 'border-border hover:border-secondary/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="block mb-1">
                          {size.size}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          Serve {size.servings} pessoas
                        </span>
                      </div>
                      <span className="text-lg text-secondary">
                        R$ {size.price.toFixed(2)}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </Card>
          )}

          {/* Quantity */}
          <div>
            <Label className="text-base mb-3 block">Quantidade</Label>
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
              >
                <Minus className="w-4 h-4" />
              </Button>
              <span className="text-2xl w-12 text-center">{quantity}</span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(quantity + 1)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Customization */}
          {product.customizable && (
            <div>
              <Label htmlFor="customization" className="text-base mb-3 block">
                Personalização (Opcional)
              </Label>
              <Textarea
                id="customization"
                placeholder="Ex: Escrever 'Parabéns Maria!', sem decoração de flores, etc."
                value={customization}
                onChange={(e) => setCustomization(e.target.value)}
                rows={3}
                className="resize-none"
              />
              <p className="text-xs text-muted-foreground mt-2">
                Descreva suas preferências e entraremos em contato se necessário.
              </p>
            </div>
          )}

          {/* Add to Cart */}
          <Card className="p-6 bg-primary text-primary-foreground">
            <div className="flex items-center justify-between mb-4">
              <span>Total:</span>
              <span className="text-3xl" style={{ fontFamily: 'var(--font-serif)' }}>
                R$ {totalPrice.toFixed(2)}
              </span>
            </div>
            <Button 
              size="lg" 
              className="w-full bg-secondary text-primary hover:bg-secondary/90"
              onClick={handleAddToCart}
            >
              <ShoppingCart className="w-5 h-5 mr-2" />
              Adicionar ao Carrinho
            </Button>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
