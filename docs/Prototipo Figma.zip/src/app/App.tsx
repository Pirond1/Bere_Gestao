import { RouterProvider } from 'react-router';
import { router } from './routes';
import { CartProvider } from './context/CartContext';
import { OrderProvider } from './context/OrderContext';
import { Toaster } from './components/ui/sonner';

export default function App() {
  return (
    <CartProvider>
      <OrderProvider>
        <RouterProvider router={router} />
        <Toaster />
      </OrderProvider>
    </CartProvider>
  );
}