export interface Product {
  id: string;
  name: string;
  category: 'cakes' | 'pies' | 'sweets';
  description: string;
  basePrice: number;
  image: string;
  featured?: boolean;
  sizes?: {
    size: string;
    servings: number;
    price: number;
  }[];
  customizable?: boolean;
}

export const products: Product[] = [
  // Cakes
  {
    id: '1',
    name: 'Bolo Red Velvet',
    category: 'cakes',
    description: 'Clássico bolo vermelho aveludado com cobertura de cream cheese e acabamento sofisticado.',
    basePrice: 69.90,
    image: 'https://images.unsplash.com/photo-1586788680434-30d324b2d46f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWQlMjB2ZWx2ZXQlMjBjYWtlfGVufDF8fHx8MTc3NDgxMTE2OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    featured: true,
    sizes: [
      { size: '15cm', servings: 12, price: 69.90 },
      { size: '20cm', servings: 20, price: 89.90 },
      { size: '25cm', servings: 30, price: 129.90 },
    ],
    customizable: true,
  },
  {
    id: '2',
    name: 'Bolo de Chocolate Belga',
    category: 'cakes',
    description: 'Bolo rico em chocolate belga 70% cacau, com ganache cremosa e decoração artesanal.',
    basePrice: 79.90,
    image: 'https://images.unsplash.com/photo-1737700088028-fae0666feb83?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaG9jb2xhdGUlMjBjYWtlJTIwZWxlZ2FudHxlbnwxfHx8fDE3NzQ3OTA5OTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    featured: true,
    sizes: [
      { size: '15cm', servings: 12, price: 79.90 },
      { size: '20cm', servings: 20, price: 99.90 },
      { size: '25cm', servings: 30, price: 149.90 },
    ],
    customizable: true,
  },
  {
    id: '3',
    name: 'Bolo de Baunilha Premium',
    category: 'cakes',
    description: 'Massa leve de baunilha madagascar com recheio de buttercream e frutas vermelhas.',
    basePrice: 65.90,
    image: 'https://images.unsplash.com/photo-1624975964661-4999f124a4c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2YW5pbGxhJTIwYmlydGhkYXklMjBjYWtlfGVufDF8fHx8MTc3NDg5OTg3NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    featured: false,
    sizes: [
      { size: '15cm', servings: 12, price: 65.90 },
      { size: '20cm', servings: 20, price: 85.90 },
      { size: '25cm', servings: 30, price: 119.90 },
    ],
    customizable: true,
  },
  
  // Pies
  {
    id: '4',
    name: 'Torta de Limão Siciliano',
    category: 'pies',
    description: 'Base crocante de massa podre, creme de limão siciliano e merengue italiano dourado.',
    basePrice: 55.00,
    image: 'https://images.unsplash.com/photo-1681329142517-6daaa56d3670?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZW1vbiUyMHBpZSUyMHRhcnR8ZW58MXx8fHwxNzc0OTAyNzcxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    featured: true,
    sizes: [
      { size: '20cm', servings: 8, price: 55.00 },
      { size: '25cm', servings: 12, price: 75.00 },
    ],
    customizable: false,
  },
  {
    id: '5',
    name: 'Torta Banoffee',
    category: 'pies',
    description: 'Clássico inglês com banana caramelizada, doce de leite e chantilly artesanal.',
    basePrice: 58.00,
    image: 'https://images.unsplash.com/photo-1633684021845-a800fb7d4e29?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b2ZmZWUlMjBjYXJhbWVsJTIwcGllfGVufDF8fHx8MTc3NDkwMjc3Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    featured: false,
    sizes: [
      { size: '20cm', servings: 8, price: 58.00 },
      { size: '25cm', servings: 12, price: 78.00 },
    ],
    customizable: false,
  },
  {
    id: '6',
    name: 'Torta de Maçã Rústica',
    category: 'pies',
    description: 'Torta artesanal com maçãs frescas temperadas com canela e crumble crocante.',
    basePrice: 52.00,
    image: 'https://images.unsplash.com/photo-1769434128977-d7619fd4d74e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcHBsZSUyMHBpZSUyMHJ1c3RpY3xlbnwxfHx8fDE3NzQ5MDI3NzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    featured: false,
    sizes: [
      { size: '20cm', servings: 8, price: 52.00 },
      { size: '25cm', servings: 12, price: 72.00 },
    ],
    customizable: false,
  },

  // Sweets
  {
    id: '7',
    name: 'Brigadeiros Gourmet',
    category: 'sweets',
    description: 'Caixa com 24 unidades de brigadeiros artesanais em sabores variados.',
    basePrice: 48.00,
    image: 'https://images.unsplash.com/photo-1767396867485-7e41ee6fec97?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwYnJpZ2FkZWlyb3MlMjBjaG9jb2xhdGV8ZW58MXx8fHwxNzc0OTAyNzcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    featured: true,
    customizable: false,
  },
  {
    id: '8',
    name: 'Macarons Franceses',
    category: 'sweets',
    description: 'Caixa com 12 macarons em sabores nobres: pistache, framboesa, baunilha e chocolate.',
    basePrice: 42.00,
    image: 'https://images.unsplash.com/photo-1681589211939-cbb7402afbc1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWNhcm9ucyUyMGNvbG9yZnVsfGVufDF8fHx8MTc3NDg5NTUzMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    featured: false,
    customizable: false,
  },
  {
    id: '9',
    name: 'Cupcakes Artesanais',
    category: 'sweets',
    description: 'Kit com 6 cupcakes decorados artisticamente em sabores variados.',
    basePrice: 38.00,
    image: 'https://images.unsplash.com/photo-1726931535415-edbc43d42c28?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXBjYWtlcyUyMGFydGlzYW58ZW58MXx8fHwxNzc0OTAyNzczfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    featured: false,
    customizable: false,
  },
];

export function getProductById(id: string): Product | undefined {
  return products.find(p => p.id === id);
}

export function getProductsByCategory(category: string): Product[] {
  return products.filter(p => p.category === category);
}

export function getFeaturedProducts(): Product[] {
  return products.filter(p => p.featured);
}
